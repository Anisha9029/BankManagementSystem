package com.bank.main;

import com.bank.model.Account;
import com.bank.service.AccountService;
import com.bank.service.impl.AccountServiceImpl;

import java.util.Scanner;

public class BankMain {

    public static void main(String[] args) {

        AccountService service = new AccountServiceImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1.Add Account\n2.Update Account\n3.Delete Account\n4.View Account\n5.View All\n6.Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    System.out.print("Acc No: ");
                    int ano = sc.nextInt();
                    System.out.print("Name: ");
                    String name = sc.next();
                    System.out.print("Balance: ");
                    double bal = sc.nextDouble();
                    service.createAccount(new Account(ano, name, bal));
                    break;

                case 2:
                    System.out.print("Acc No: ");
                    ano = sc.nextInt();
                    System.out.print("New Name: ");
                    name = sc.next();
                    System.out.print("New Balance: ");
                    bal = sc.nextDouble();
                    service.updateAccount(new Account(ano, name, bal));
                    break;

                case 3:
                    System.out.print("Acc No: ");
                    service.deleteAccount(sc.nextInt());
                    break;

                case 4:
                    System.out.print("Acc No: ");
                    Account acc = service.viewAccount(sc.nextInt());
                    if (acc != null)
                        System.out.println(acc.getAccNo()+" "+acc.getName()+" "+acc.getBalance());
                    else
                        System.out.println("Account not found");
                    break;

                case 5:
                    for (Account a : service.viewAllAccounts()) {
                        System.out.println(a.getAccNo()+" "+a.getName()+" "+a.getBalance());
                    }
                    break;

                case 6:
                    System.exit(0);
            }
        }
    }
}
