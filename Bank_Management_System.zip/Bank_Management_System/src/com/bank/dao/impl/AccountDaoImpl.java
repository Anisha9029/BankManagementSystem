package com.bank.dao.impl;

import com.bank.dao.AccountDao;
import com.bank.model.Account;
import com.bank.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDaoImpl implements AccountDao {

    Connection con = DBUtil.getConnection();

    public void addAccount(Account acc) {
        try {
            String sql = "INSERT INTO account VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, acc.getAccNo());
            ps.setString(2, acc.getName());
            ps.setDouble(3, acc.getBalance());
            ps.executeUpdate();
            System.out.println("Account Added Successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateAccount(Account acc) {
        try {
            String sql = "UPDATE account SET name=?, balance=? WHERE acc_no=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, acc.getName());
            ps.setDouble(2, acc.getBalance());
            ps.setInt(3, acc.getAccNo());
            ps.executeUpdate();
            System.out.println("Account Updated Successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteAccount(int accNo) {
        try {
            String sql = "DELETE FROM account WHERE acc_no=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, accNo);
            ps.executeUpdate();
            System.out.println("Account Deleted Successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Account getAccount(int accNo) {
        Account acc = null;
        try {
            String sql = "SELECT * FROM account WHERE acc_no=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, accNo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                acc = new Account(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getDouble(3)
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return acc;
    }

    public List<Account> getAllAccounts() {
        List<Account> list = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM account");
            while (rs.next()) {
                list.add(new Account(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getDouble(3)
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}

