package com.bank.dao;

import com.bank.model.Account;
import java.util.List;

public interface AccountDao {
    void addAccount(Account acc);
    void updateAccount(Account acc);
    void deleteAccount(int accNo);
    Account getAccount(int accNo);
    List<Account> getAllAccounts();
}
