package com.bank.service.impl;

import com.bank.dao.AccountDao;
import com.bank.dao.impl.AccountDaoImpl;
import com.bank.model.Account;
import com.bank.service.AccountService;

import java.util.List;

public class AccountServiceImpl implements AccountService {

    AccountDao dao = new AccountDaoImpl();

    public void createAccount(Account acc) {
        dao.addAccount(acc);
    }

    public void updateAccount(Account acc) {
        dao.updateAccount(acc);
    }

    public void deleteAccount(int accNo) {
        dao.deleteAccount(accNo);
    }

    public Account viewAccount(int accNo) {
        return dao.getAccount(accNo);
    }

    public List<Account> viewAllAccounts() {
        return dao.getAllAccounts();
    }
}
