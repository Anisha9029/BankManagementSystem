package com.bank.service;

import com.bank.model.Account;
import java.util.List;

public interface AccountService {
    void createAccount(Account acc);
    void updateAccount(Account acc);
    void deleteAccount(int accNo);
    Account viewAccount(int accNo);
    List<Account> viewAllAccounts();
}
