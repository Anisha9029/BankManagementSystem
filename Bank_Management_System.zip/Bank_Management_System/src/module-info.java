/**
 * 
 */
/**
 * 
 */
module Bank_Management_System {
	requires java.sql;
}